import "./App.css";
import { BrowserRouter, Routes, Route } from "react-router-dom";
 import { Home, Feed, Dashboard, Create,Login } from "./pages"
//import { Home, Feed, Dashboard, Create } from "./pages"

import Header from './Header'; //Include Heder
import Footer from './Footer'; //Include Footer
function App() {
  return (
    <BrowserRouter>
       <Header></Header>
      <Routes>
          <Route path="/" element={<Home />} />
          
          <Route path="/employer" >
          
          <Route path="/employer/dashboard" element={<Dashboard />}/>
          <Route path="/employer/create" element={<Create />}/>
          </Route>
          <Route path="/employee/login"  element={<Login />}/>
          <Route path="/employee/feed" element={<Feed />}/>
      </Routes>
      <Footer></Footer>
    </BrowserRouter>
  );
}

export default App;
