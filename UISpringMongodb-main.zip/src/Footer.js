import React from 'react';
import './App.css';
//import 'bootstrap/dist/css/bootstrap.min.css';
class Footer extends React.Component
{
  render()
  {
    return (
<div>
    
    {/*
    <div class="jumbotron text-center">
    <script>
    var link = document.createElement('link');
    link.rel = 'stylesheet';
  
  link.type = 'text/css';

  link.href = 'https://maxcdn.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css';
  document.getElementsByTagName('div')[0].appendChild(link);

    </script> */}

<footer>
©2022 Copyright:
 <a href="/"> JournalUser.com</a>

</footer>

</div>

    )
  }
}
export default Footer;