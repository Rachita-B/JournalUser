import React from 'react';
import ReactDOM from 'react-dom/client';
import './index.css';
import App from './App';
// import './js/validation.js';
//<script type="text/javascript" src="./js/validation.js"></script>
const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(<App />);
