//<script type="text/javascript" src="js/js.js"></script>

//**************js.js file*****************


function validatestudent_id(student_id) {
    var re_student_id = /^(\+84|0)[3|5|7|8|9][1-9]\d{7}$/;
    return re_student_id.test(student_id);
}
function check_name(name) {
    var message_name="";
    if (name.value==="") {
        name.style.border='1px solid red';
        message_name="Please enter your name !";
        document.getElementById('message_name').innerHTML=message_name;
        return 0;
    } else if (name.value.length<7) {
        name.style.border='1px solid red';
        message_name="Please enter your full name !";
        document.getElementById('message_name').innerHTML=message_name;
        return 0;
    } else {
        name.style.border='1px solid green';
        message_name="";
        document.getElementById('message_name').innerHTML=message_name;
        return true;
    }
}
function check_university_name(university_name) {
    var message_university_name="";
    if (university_name.value==="") {
        university_name.style.border='1px solid red';
        message_university_name="Please enter your university name !";
        document.getElementById('message_university_name').innerHTML=message_university_name;
        return 0;
    } else if (university_name.value.length<7) {
        university_name.style.border='1px solid red';
        message_university_name="Please enter your full university name !";
        document.getElementById('message_university_name').innerHTML=message_university_name;
        return 0;
    } else {
        university_name.style.border='1px solid green';
        message_university_name="";
        document.getElementById('message_university_name').innerHTML=message_university_name;
        return true;
    }
}

function check_student_id(student_id) {
    var message_student_id="";
    if (student_id.value==="") {
        student_id.style.border='1px solid red';
        message_student_id="Please enter your student_id !";
        document.getElementById('message_student_id').innerHTML=message_student_id;
        return 0;
    } else if (!validatestudent_id(student_id.value)) {
        student_id.style.border='1px solid red';
        message_student_id="student_id invalid !";
        document.getElementById('message_student_id').innerHTML=message_student_id;
        return 0;
    } else {
        student_id.style.border='1px solid green';
        message_student_id="";
        document.getElementById('message_student_id').innerHTML=message_student_id;
        return 1;
    }
}
function check_student_code(student_code) {
    var message_student_code="";
    if (student_code.value==="") {
        student_code.style.border='1px solid red';
        message_student_code="Please enter your student_code it should be alpha numeric \n combination of (0-9)and (A-Z) !";
        document.getElementById('message_student_code').innerHTML=message_student_code;
        return 0;
    } else {
        student_code.style.border='1px solid green';
        message_student_code="";
        document.getElementById('message_student_code').innerHTML=message_student_code;
        return 1;
    }
}
function check(){
//export function check(e){

    var name = document.getElementById('name');
    var university_name = document.getElementById('university_name');
   // var address = document.getElementById('address');
    var student_id = document.getElementById('student_id');
    var student_code = document.getElementById('student_code');
    // var password = document.getElementById('password');
    // var conf_password = document.getElementById('conf_password');
    check_name(name);
    if (check_name(name)==="") {
        return;
    };
    check_university_name(university_name);
    if (check_university_name(university_name)==="") {
        return;
    };
    check_student_code(student_code);
    if (check_student_code(student_code)==="") {
        return;
    };
    check_student_id(student_id);
    if (check_student_id(student_id)===0) {
        return;
    };
  
    window.location.reload(); //Refresh page
}
export{check};
