import React, { useState } from "react";
//import { format } from 'date-fns';
//import dateFormat from 'dateformat';
//import DatePicker from "react-datepicker";
//import {omit} from 'lodash';
//import {check} from '../js/validation.js';
//import useForm from '../Hooks/useForm';
//import { navbar} from "../templates/partials/navbar.hbs";

import {
  Typography,
  TextField,
  Button,
  Paper,
  Box,
} from "@mui/material";

import { useNavigate } from "react-router-dom";

//const initial = { name: "",student_code:"", university_id: "",journal_id:"",student_id:"", university_name:"",subscription_end_date:"" ,validation:false};
const initial = { name: "",student_code:"", university_id: "",journal_id:"",student_id:"", university_name:"",subscription_end_date:"" };

//const initial = { profile: "", exp: 0, techs: [], desc:"" };
 const Create = () => {
 // console.log(format(new Date(), 'yyyy/MM/dd kk:mm:ss'))
  const navigate = useNavigate();
  const [form, setForm] = useState(initial);
  const [erro, seterro] = useState("");
  //const [erro1, seterro1] = useState("");
  //Custom hook call
 // const {handleChange, values,errors } = useForm();

//  React.useEffect(() => {
//   // Set errorMessage only if text is equal or bigger than MAX_LENGTH
//  if(form.student_code!=new RegExp("^(?=.*[a-zA-Z])(?=.*[0-9])[A-Za-z0-9]+$"))
//  {
  
//   seterro("error")
//  }
//  if(form.student_code==new RegExp("^(?=.*[a-zA-Z])(?=.*[0-9])[A-Za-z0-9]+$"))
//  {
//   seterro("")
//  }
// }, [form]);
const onCheck = (e) => {
  e.preventDefault();
// if(form.student_code!=new RegExp('^[a-zA-Z0-9_]+$'))
  // if(form.student_code!="hello")^[0-9a-zA-Z]+$

//   if(form.name.match(new RegExp('^[a-zA-Z]+$')))
//  {console.log("value is only String")
// handleSubmit(e) 
//}
  // else  {
  //   console.log("not a string, have numbers or other ")
  //   seterro1("student name should be only characters")
  //  }
  //Validation on Student code
  
                  if(form.student_code.match(new RegExp('^[0-9a-zA-Z]+$')))
                         {console.log("alphanuneric")
                          handleSubmit(e)}
                  else  {
                            console.log("not alphanumeric")
                           seterro("student code should be alpha numeric(combination of 0-9 or a-z or A-z)")
                        }
  
  
};

  const handleSubmit = (e) => {
   
    e.preventDefault();
    
    //onclick='check()';
    //await check()   // works only with async async(e)
  //  if (useState.validation == true) {
    //**************ADDING data to university_detail table******************
    fetch("http://localhost:8080/university", {
      method: "POST", // or 'PUT'
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(form),
    })
      .then((response) => console.log(response))
      .then((data) => {
        console.log("Success:", data);
      })
      .catch((error) => {
        console.error("Error:", error);
      });
      //***************ADDING data to user table*****************
    fetch("http://localhost:8080/post", {
      method: "POST", // or 'PUT'
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(form),
    })
      .then((response) => console.log(response))
      .then((data) => {
        console.log("Success:", data);
      })
      .catch((error) => {
        console.error("Error:", error);
      });
     // navigate('/employee/feed');
     
      navigate('../../');
      alert("Data submitted");
    // }
    // else{
    //   alert("fillagain");
    // }
  };
 
  const { name,student_id, university_id, journal_id,student_code,university_name,subscrption_end_date } = form;
 //  //Final submit function
 //   const formLogin = () => {

 //     console.log("Callback function when form is submitted!");
  //     console.log("Form Values ", values);
 //   }

 //   //Custom hook call
 //   const {values} = useForm(formLogin);


    // const handleChange=(e)=>{
    //  setForm({...form,name:e.target.value});
    // }

  // const handleChange = (e) => {
  //   setForm({...form , techs : [...form.techs, e.target.value]});
  // }


 //dateFormat(subscrption_end_date,"yyyy-mm-dd");
 //alert(dateFormat(subscrption_end_date, "yyyy-mm-dd") );
 //dateFormat("2019-04-30T08:59:00.000Z", "mmmm dS, yyyy") 
  return (
    <Paper sx={{ padding:"2%"}} elevation={3}>
      <Typography sx={{ margin: "3% auto" }} align="center" variant="h5">
        Student Details
      </Typography>
      <form autoComplete="off" onSubmit={onCheck} >
        
        <Box
          sx={{
            display: "flex",
            justifyContent: "center",
            flexDirection: "column",
          }}
        >
    {/* <input type="text" style={{"width":"50%"}} onChange={(e) => setForm({ ...form, name: e.target.value })}  placeholder="Student Name"
            variant="outlined"
            value={name} required/> */}
         <TextField
         // required="true"
          //required={required}
            
           
            type="string"
            sx={{ width: "50%", margin: "2% auto" }}
            required
            onChange={(e) => setForm({ ...form, name: e.target.value})}
           // onChange={handleChange}
            label="Student Name"
            variant="outlined"
            value={name}
            //focused
            //onfilled
          
          />
           {/* <span style={{color: 'red', paddingLeft: '250px',marginTop:"0px"}}>{erro1}</span>
           */}
          <TextField
            type="string"
            sx={{ width: "50%", margin: "2% auto" }}
            required
            onChange={(e) => setForm({ ...form, student_code: e.target.value })}
            label="Student Code"
            variant="outlined"
            value={student_code}
          />
          <span style={{color: 'red', paddingLeft: '250px',marginTop:"0px"}}>{erro}</span>
          <TextField
            type="number"
            sx={{ width: "50%", margin: "2% auto" }}
            required
            onChange={(e) => setForm({ ...form, student_id: e.target.value })}
          // onChange={handleChange}
            label="Student id"
            variant="outlined"
            value={student_id}
          />
           {/* {
        errors.student_id && <h3>{errors.student_id}</h3>

      } */}
           <TextField
            type="number"
            sx={{ width: "50%", margin: "2% auto" }}
            required
            onChange={(e) => setForm({ ...form, university_id: e.target.value })}
            label="University id"
            variant="outlined"
            value={university_id}
          />
          <TextField
            type="string"
            sx={{ width: "50%", margin: "2% auto" }}
            required
            onChange={(e) => setForm({ ...form, university_name: e.target.value })}
            label="University name"
            variant="outlined"
            value={university_name}
          />
              <TextField
            type="number"
            sx={{ width: "50%", margin: "2% auto" }}
             required
            // multiline
            // rows={4}
            onChange={(e) => setForm({ ...form, journal_id: e.target.value })}
            label="Journal id"
            variant="outlined"
            value={journal_id}
          />
              
              <TextField
            type="Date"
            sx={{ width: "50%", margin: "2% auto" }}
            required
            onChange={(e) => setForm({ ...form, subscrption_end_date: e.target.value })}
            label="subscription end date"
            
            variant="outlined"
            value={subscrption_end_date}
          />
         
       
          <Button
            sx={{ width: "50%", margin: "2% auto" }}
            variant="contained"
      //    onclick={check}
            type="submit"
          >
            Submit
          </Button>
        </Box>
      </form>
    
    </Paper>
  
  );
};

export default Create;
