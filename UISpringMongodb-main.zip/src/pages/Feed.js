import {
  Box,
  Card,
  Grid,
  TextField,
  Typography,
  InputAdornment,
  //Button,
} from "@mui/material";
import axios from "axios";
import React, { useEffect, useState } from "react";
import SearchIcon from "@mui/icons-material/Search";
//import { Link } from "react-router-dom";

const Feed = () => {
  const [query, setQuery] = useState("");
  const [post, setPost] = useState();

  //
  useEffect(() => {
    const fetchPosts = async () => {
      const response = await axios.get(`http://localhost:8080/posts/${query}`);
      setPost(response.data);
    };
    const fetchInitialPosts = async () => {
        const response = await axios.get(`http://localhost:8080/allPosts`);
        console.log(response);
        setPost(response.data);
    }
    if (query.length === 0) fetchInitialPosts();
    if (query.length > 1) fetchPosts();
  }, [query]);
console.log(post);
  return (
    <Grid container spacing={2} sx={{ margin: "2%" }}>
      <Grid item xs={12} sx={12} md={12} lg={12}>
      {/* <Button sx={{ margin: "1% 2%" }} variant="outlined">
            <Link to="/">Home</Link>
          </Button> */}
        <Box>
        {/*  <b> Enter search code</b> */}
          <TextField
            InputProps={{
              startAdornment: (
                <InputAdornment position="start">
                  <SearchIcon />
                </InputAdornment>
              ),
            }}
            placeholder="Enter student code"
         //   sx={{ width: "15%", padding: "2% auto" }}
            sx={{ width: "75%", padding: "2% auto",marginTop:"-1%"  }}
            fullWidth
            onChange={(e) => setQuery(e.target.value)}
          />
        </Box>
      </Grid>
      {post &&
        post.map((p) => {
          return (
            <Grid key={p.id} item xs={12} md={6} lg={4}>
              <Card sx={{ padding: "3%", overflow: "hidden", width: "84%" }}>
                <Typography
                  variant="h5"
                  sx={{ fontSize: "2rem", fontWeight: "600" }}
                >
             {p.name}
                </Typography>
                <br/>
                <Typography variant="h6">
                Student Details:
                </Typography>
                
                
                <Typography sx={{ color: "#585858", marginTop:"2%" }} variant="body" >
                Student Name: {p.name}
                   <br />
                Student Code: {p.student_code}
                   <br />
                  Student Id: {p.student_id}
                   <br />
                   <br/>
                   <Typography variant="h6" sx={{ color:'Black' }}>
                   University Details:
                </Typography>
                
                   University Id: {p.university_id}
                   <br />
                   University Name: {p.university_name}
                   <br />
                   <br/>
                   <Typography variant="h6" sx={{ color:'Black' }}>
                   Journal Details:
                </Typography>
                
                  Journal Id: {p.journal_id}
                   <br/>
                   Subscription End Date: {p.subscrption_end_date}
                   <br />
                </Typography>
                
                

  
              </Card>
            </Grid>
          );
        })}
    </Grid>
  );
};

export default Feed;
