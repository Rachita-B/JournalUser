import React from "react";
import { Typography, Button } from "@mui/material";
import { Link } from "react-router-dom";
import "../App.css"
const styles = {
  display: 'flex',
  alignItems: 'center',
  justifyContent: 'center',
 
};
const Home = () => {
  return (
    <div>
      
      <Typography sx={{ margin:"5%" }} variant="h3" align="center">
      <h2> JOURNAL USER APPLICATION</h2>
         Start Your Day With Positive Thinking...
      </Typography>
      
      <div style={styles} >

        
          <Button sx={{ margin:"2% 3%", background: "darkgrey" }} variant="outlined"  >
            <Link to="/employer/dashboard" style={{textDecoration:"none"}}>
              ADD USER
            </Link>
            </Button>
        
          <Button sx={{ margin:"2% 3%", background: "darkgrey"}} variant="outlined" >
            <Link to="/employee/feed" style={{textDecoration:"none"}}>
            {/* <Link to="/employee/login" style={{textDecoration:"none"}}> */}
              MEMBER
            </Link>
            </Button>
         
      </div>
    </div>
  );
};

export default Home;
