//HardCoded Values for login 
import React, { useState } from "react";
//import React, { useState,useHistory } from "react";

import {
  Typography,
  TextField,
  Button,
  Paper,
 // Box,
} from "@mui/material";

import { useNavigate } from "react-router-dom";

 const Login = () => {
    
    const [emailInput, setEmailInput] = useState('');
    const [passwordInput, setPasswordInput] = useState('');
    const navigate = useNavigate();
    //const history = useHistory();
    
    const handleEmailChange = (e) => {
        setEmailInput(e.target.value);
    }
    
    const handlePasswordChange = (e) => {
        setPasswordInput(e.target.value);
    }
    
    const handleLoginSubmit = (e) => {
        e.preventDefault();
        let hardcodedCred = {
            email: 'rachita@gmail.com',
            password: 'password123'
        }
    
        if ((emailInput === hardcodedCred.email) && (passwordInput === hardcodedCred.password)) {
            navigate('/employee/feed');
        }
        else
        {  alert('wrong email or password combination');
        navigate('/employee/login');
        }
        //By creating a token
        // if ((emailInput === hardcodedCred.email) && (passwordInput === hardcodedCred.password)) {
        //     //combination is good. Log them in.
        //     //this token can be anything. You can use random.org to generate a random string;
        //     const token = '123456abcdef';
        //     sessionStorage.setItem('auth-token', token);
        //     //go to www.website.com/todo
        // //    history.push('/todo');
        // } else {
        //     //bad combination
        //     alert('wrong email or password combination');
        // }
    }
    
    // if (!sessionStorage.getItem('auth-token')) {
    //     console.log('no auth token set');
    //     navigate('/employee/login');
    //     //do something like redirect to login page
        
    // } else {
    //     const authToken = '123456abcdef';
    //     if (sessionStorage.getItem('auth-token') === authToken) {
    //         console.log('good token. Log in.')
    //         navigate('/employee/feed');
    //         //do something like redirect to todo page
    
    //     } else {
    //         console.log('bad token.')
    //         navigate('/employee/login');
    //         //do something like redirect to login page
    //     }
    // }
  

    return (
        <Paper sx={{ padding:"2%"}} elevation={3}>
        <Typography sx={{ margin: "3% auto" }} align="center" variant="h5">
          Admin Login
        </Typography>
        
            <form autoComplete="off" onSubmit={handleLoginSubmit} align="center">
         
                 <TextField
                type="string"
                sx={{ width: "50%", margin: "2% auto" }}
                id="exampleInputEmail1"
                label="Enter Email"
                variant="outlined"
                value={emailInput}
                onChange={handleEmailChange}
                required
              /> <br/>
              <TextField
                type="password"
                sx={{ width: "50%", margin: "2% auto" }}
                id="exampleInputPassword1"
                label="Enter Password"
                variant="outlined"
                value={passwordInput}
                onChange={handlePasswordChange}
                required
              /> 
                     {/* 
                     <div className="form-group">
                    <input
                    type="email"
                    className="form-control"
                    id="exampleInputEmail1"
                    aria-describedby="emailHelp"
                    placeholder="Enter email"
                    value={emailInput}
                    onChange={handleEmailChange}
                    />
                </div>
                <div className="form-group">
                    <input
                    type="password"
                    autoComplete="new-password"
                    className="form-control"
                    id="exampleInputPassword1"
                    placeholder="Password"
                    value={passwordInput}
                    onChange={handlePasswordChange}
                    />
                </div> 
                 <button type="submit" className="btn btn-primary">;
                    Submit
                </button>;
                 */}
                 <br/>
                <Button
            sx={{ width: "50%", margin: "2% auto" }}
            variant="contained"
            type="submit"
          >
            Submit
          </Button>
          </form>
        </Paper>
          );
};

export default Login;
